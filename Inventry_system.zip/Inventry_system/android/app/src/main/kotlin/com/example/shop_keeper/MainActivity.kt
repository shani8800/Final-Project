package com.example.shop_keeper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
